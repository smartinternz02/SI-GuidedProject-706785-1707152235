<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_2                                        _15cda4</name>
   <tag></tag>
   <elementGuidId>48534765-7541-42c4-94d2-ea0103bdaeb0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='nav-cart']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#nav-cart</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>10cc097f-ff7d-4e9a-b678-9935c09b8226</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/gp/cart/view.html?ref_=nav_cart</value>
      <webElementGuid>befdc96c-c7c5-4b36-bca0-0cc503b97a42</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>2 items in cart</value>
      <webElementGuid>0944c69b-0d4f-4377-b30a-77fde12ac9c4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-a nav-a-2 nav-progressive-attribute</value>
      <webElementGuid>90365795-7a13-4c40-b964-0455034945b1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>nav-cart</value>
      <webElementGuid>9e3d25da-b22b-42ed-91f5-534c3661a988</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
      2
      
    
    
      
        
      
      
        Cart
        
      
    
  </value>
      <webElementGuid>2c99aa8e-c8d1-41be-833f-bac51a5bad50</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;nav-cart&quot;)</value>
      <webElementGuid>c6b6068d-7216-4334-bea1-3c1946e1cadc</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//a[@id='nav-cart']</value>
      <webElementGuid>fc7ff89b-b464-45e5-b53e-688ca7921414</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='nav-tools']/a[5]</value>
      <webElementGuid>865050f1-7301-4361-b4eb-a6b9d2b9bf0e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/gp/cart/view.html?ref_=nav_cart')]</value>
      <webElementGuid>be328728-de26-4f97-bfd3-ff083b37aa15</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[5]</value>
      <webElementGuid>9eec1d34-00b3-444d-9cb1-7776ecb85442</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/gp/cart/view.html?ref_=nav_cart' and @id = 'nav-cart' and (text() = '
    
      2
      
    
    
      
        
      
      
        Cart
        
      
    
  ' or . = '
    
      2
      
    
    
      
        
      
      
        Cart
        
      
    
  ')]</value>
      <webElementGuid>934a31ce-9ff9-481d-a984-ad159bd9405c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
